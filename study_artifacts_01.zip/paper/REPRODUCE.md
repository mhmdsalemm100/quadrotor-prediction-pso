# Reproducing the manuscript analyses

Extract Scientific_Supplement.zip. The `study` directory preserves the original study hierarchy. The `paper` directory contains the analysis script and numerical exports. No optimization run is required to reproduce the new statistics and convergence curves.

Use a Python environment with NumPy, SciPy, Numba and Matplotlib. The recorded model-fitting environment used scikit-learn 1.5.2 and joblib. Load only the trusted model files supplied in this archive. The serialized predictors can be inspected without retraining. Historical frozen scripts and protocols preserve their original absolute paths and hashes, which document provenance rather than portable launch commands.

Set `QUADROTOR_STUDY_ROOT` to the absolute path of the extracted `study` directory. Set `NUMBA_CACHE_DIR` and `MPLCONFIGDIR` to writable temporary folders if needed. Run `python paper/analyze_revision.py`. It reads the archived results, reconstructs convergence, enumerates the 1024 whole-plant label swaps, creates bootstrap intervals with seed 6801, calculates conditional costs, and replays two development controllers. It writes only paper artifacts. The model and test results are not changed.

The supplied outcomes figure originates from the archived final-test report. The analysis exports include per-evaluation convergence summaries, exact-test inputs, cost calculations, model settings, and development trace arrays. The original final-run CSV and full evaluation ledgers provide the final gain vectors and all reported outcomes.

Scientific_Supplement.zip includes the 600 training-run JSON summaries needed to reproduce labels. It does not include their full historical ledgers or every discarded development experiment. Costs for those historical stages are reported in the archived offline-cost record. The current final-test ledgers are included for all 150 runs.

Extract MDPI_Manuscript_Source.zip separately and compile main.tex with a working LaTeX installation, for example `tectonic main.tex` or the appropriate LaTeX engine in an online editor. Definitions/mdpi.cls is the unchanged locally available MDPI class. draft_layout.tex suppresses publisher identifiers and replaces the EPS publisher logo with a draft label for compiler compatibility. Aerospace is a provisional class option. Author fields and declarations must be completed before submission.

The manuscript source and scripts remain local. No journal submission, repository publication or external data upload has been performed.
