import numpy as np
import time
from experiment import backend as b
def optimize(d,seed,centers,budget):
    cfg=b.original.config(); rng=np.random.default_rng(seed); n=64
    x=rng.random((n,8))
    for j in range(8): x[:,j]=(rng.permutation(n)+rng.random(n))/n
    x[0]=b.encode(b.baseline(),cfg); v=rng.uniform(-.1,.1,(n,8))
    noise=np.random.default_rng(seed+910000); centers=np.clip(centers,0,1)
    x[1:1+len(centers)]=centers
    for i in range(1+len(centers),33): x[i]=np.clip(centers[(i-1)%len(centers)]+noise.normal(0,.025,8),0,1)
    initial=x.copy(); initial_v=v.copy(); personal=x.copy(); pf=np.full(n,np.inf); cache={}; ledger=[]; best=np.inf; bestx=None; it=0; start=time.perf_counter()
    while len(cache)<budget:
        values=[]
        for p in x:
            key=tuple(np.round(p,13))
            if key not in cache:
                if len(cache)>=budget: break
                value=float(b.evaluate(b.decode(p,cfg),b.original.cases_for(d),cfg)); assert np.isfinite(value)
                cache[key]=value
                if value<best: best=value; bestx=p.copy()
                ledger.append([len(cache),it,value,best,*p])
            values.append(cache[key])
        if len(cache)>=budget: break
        f=np.array(values); improve=f<pf; personal[improve]=x[improve]; pf[improve]=f[improve]
        progress=max(0,min(1,(len(cache)-64)/(budget-64)))
        v=(.9-.5*progress)*v+1.7*rng.random((n,8))*(personal-x)+1.7*rng.random((n,8))*(bestx-x)
        v=np.clip(v,-.2,.2); trial=x+v; hit=(trial<0)|(trial>1); x=np.clip(trial,0,1); v[hit]*=-.5; it+=1
        if it>10000: raise RuntimeError('Optimizer stalled')
    return {'seed':seed,'gains':b.decode(bestx,cfg).tolist(),'fitness':best,'unique_evaluations':budget,'seconds':time.perf_counter()-start},np.array(ledger),initial,initial_v


