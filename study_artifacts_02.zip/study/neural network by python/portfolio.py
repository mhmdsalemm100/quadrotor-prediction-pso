"""Second, separately versioned initializer: predictions plus training-only controller library."""
from pathlib import Path
import json,sys,time,hashlib
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np
import experiment as ex
b=ex.backend; ROOT=ex.ROOT/'portfolio'; ROOT.mkdir(exist_ok=True)
def save(n,o): b.save(ROOT/n,o)

def optimize(d,seed,centers):
    cfg=b.original.config(); rng=np.random.default_rng(seed); n=64
    x=rng.random((n,8))
    for j in range(8): x[:,j]=(rng.permutation(n)+rng.random(n))/n
    x[0]=b.encode(b.baseline(),cfg); v=rng.uniform(-.1,.1,(n,8))
    noise=np.random.default_rng(seed+910000); centers=np.clip(centers,0,1)
    x[1:1+len(centers)]=centers
    for i in range(1+len(centers),33): x[i]=np.clip(centers[(i-1)%len(centers)]+noise.normal(0,.025,8),0,1)
    initial=x.copy(); initial_v=v.copy(); personal=x.copy(); pf=np.full(n,np.inf); cache={}; ledger=[]; best=np.inf; bestx=None; it=0; start=time.perf_counter()
    while len(cache)<900:
        values=[]
        for p in x:
            key=tuple(np.round(p,13))
            if key not in cache:
                if len(cache)>=900: break
                value=float(b.evaluate(b.decode(p,cfg),b.original.cases_for(d),cfg)); assert np.isfinite(value)
                cache[key]=value
                if value<best: best=value; bestx=p.copy()
                ledger.append([len(cache),it,value,best,*p])
            values.append(cache[key])
        if len(cache)>=900: break
        f=np.array(values); improve=f<pf; personal[improve]=x[improve]; pf[improve]=f[improve]
        progress=max(0,min(1,(len(cache)-64)/(900-64)))
        v=(.9-.5*progress)*v+1.7*rng.random((n,8))*(personal-x)+1.7*rng.random((n,8))*(bestx-x)
        v=np.clip(v,-.2,.2); trial=x+v; hit=(trial<0)|(trial>1); x=np.clip(trial,0,1); v[hit]*=-.5; it+=1
        if it>10000: raise RuntimeError('Optimizer stalled')
    return {'seed':seed,'gains':b.decode(bestx,cfg).tolist(),'fitness':best,'unique_evaluations':900,'seconds':time.perf_counter()-start},np.array(ledger),initial,initial_v

def centers_for(d,allowed,plants,pred1,pred2):
    keys=['inertia_scale','motor_tau_s','rotor_scale']; scale=np.array([.3,.012,.2]); q=np.array([d[k] for k in keys])
    nearest=sorted(allowed,key=lambda name:float(np.sum(((np.array([plants[name][k] for k in keys])-q)/scale)**2)))[:4]
    centers=[pred1,pred2]; provenance=[]; cfg=b.original.config()
    for name in nearest:
        runs=sorted([json.loads(p.read_text()) for p in (ex.STUDY/'drones'/name/'runs').glob('*.json')],key=lambda r:r['fitness'])[:5]
        for r in runs:
            centers.append(b.encode(np.array(r['gains']),cfg).tolist()); provenance.append({'source_drone':name,'source_seed':r['seed']})
    assert d['id'] not in nearest
    return centers,provenance

def worker(d,seed,centers,stage,method):
    if method=='single_prediction':
        r,z,x,v=b.optimize(b.original.config(),b.original.cases_for(d),seed,np.array(centers[0]))
    else: r,z,x,v=optimize(d,seed,centers)
    if stage=='training_cv':
        _,details=b.evaluate(np.array(r['gains']),b.original.cases_for(d),b.original.config(),True)
        r['training_feasible']=all(q['feasible'] for q in details)
    else: r.update(b.metrics(d,r['gains'],b.original.config()))
    r.update(drone=d['id'],method=method)
    folder=ROOT/stage/d['id']; folder.mkdir(parents=True,exist_ok=True)
    np.savez_compressed(folder/f'{method}_{seed}.npz',ledger=z,initial=x,initial_velocity=v)
    b.save(folder/f'{method}_{seed}.json',r)
    return r

def main():
    import msvcrt
    lock=open(ROOT/'run.lock','a+b'); lock.write(b'0'); lock.flush(); lock.seek(0); msvcrt.locking(lock.fileno(),msvcrt.LK_NBLCK,1)
    b.original.verify_contract()
    bundle=json.loads((ex.ROOT/'candidate_predictions.json').read_text()); plants={d['id']:d for d in json.loads((ex.STUDY/'manifest.json').read_text())['drones']}
    selected=json.loads((ex.ROOT/'selection.json').read_text())['selected']; candidates=[next(c for c in bundle['candidates'] if c['name']==n) for n in selected]
    if (ROOT/'protocol.json').exists():
        previous=json.loads((ROOT/'protocol.json').read_text())
        assert previous['code_sha256']==ex.sha(Path(__file__)) and previous['prediction_sha256']==ex.sha(ex.ROOT/'candidate_predictions.json')
    banks={}; sources={}
    for idx,name in enumerate(bundle['training_ids']):
        allowed=next(f['train'] for f in bundle['folds'] if name in f['held_out'])
        banks[name],sources[name]=centers_for(plants[name],allowed,plants,candidates[0]['oof'][idx],candidates[1]['oof'][idx])
    save('protocol.json',{'code_sha256':ex.sha(Path(__file__)),'prediction_sha256':ex.sha(ex.ROOT/'candidate_predictions.json'),'source_models':selected,'initialization':'baseline + two predicted vectors + 20 training-only nearest-library controllers + 10 perturbed centers + 31 global particles','budget':900,'training_screen_seed':39001,'selection':'Compare 20 whole-drone out-of-fold single-prediction and portfolio PSO runs; prefer more feasible, then lower mean log fitness. Test portfolio on development validation only if it wins.','scope':'Exploratory development extension; no final unseen claim','library_provenance_for_training':sources})
    jobs=[(plants[name],39001,banks[name],'training_cv',method) for name in bundle['training_ids'] for method in ['single_prediction','portfolio'] if not (ROOT/'training_cv'/name/f'{method}_39001.json').exists()]
    save('STATUS.json',{'status':'TRAINING_CV','completed':40-len(jobs),'total':40})
    done=40-len(jobs)
    with ProcessPoolExecutor(max_workers=4) as pool:
        for f in as_completed([pool.submit(worker,*j) for j in jobs]):
            r=f.result(); done+=1; print(f"Training CV {done}/40 {r['drone']} {r['method']}",flush=True); save('STATUS.json',{'status':'TRAINING_CV','completed':done,'total':40})
    scores=[]
    for method in ['single_prediction','portfolio']:
        rr=[json.loads((ROOT/'training_cv'/n/f'{method}_39001.json').read_text()) for n in bundle['training_ids']]
        scores.append({'method':method,'feasible':sum(r['training_feasible'] for r in rr),'mean_log_fitness':float(np.mean(np.log([r['fitness'] for r in rr])))})
    scores.sort(key=lambda r:(-r['feasible'],r['mean_log_fitness'])); save('training_comparison.json',scores)
    if scores[0]['method']!='portfolio':
        save('STATUS.json',{'status':'COMPLETE_NOT_SELECTED','training_comparison':scores}); return
    jobs=[]; provenance={}
    for idx,name in enumerate(bundle['validation_ids']):
        centers,provenance[name]=centers_for(plants[name],bundle['training_ids'],plants,candidates[0]['predictions'][idx],candidates[1]['predictions'][idx])
        for seed in ex.SEEDS:
            if not (ROOT/'validation'/name/f'portfolio_{seed}.json').exists(): jobs.append((plants[name],seed,centers,'validation','portfolio'))
    save('validation_library_provenance.json',provenance); done=30-len(jobs)
    with ProcessPoolExecutor(max_workers=4) as pool:
        for f in as_completed([pool.submit(worker,*j) for j in jobs]):
            r=f.result(); done+=1; print(f"Validation {done}/30 {r['drone']} seed {r['seed']}",flush=True); save('STATUS.json',{'status':'VALIDATION','completed':done,'total':30})
    rows=[]; gains=[]
    for name in bundle['validation_ids']:
        for seed in ex.SEEDS:
            path=ROOT/'validation'/name/f'portfolio_{seed}.json'; r=json.loads(path.read_text()); z=np.load(path.with_suffix('.npz'))
            ledger=z['ledger']; assert ledger.shape==(900,12) and len(np.unique(np.round(ledger[:,4:],13),axis=0))==900
            assert np.array_equal(ledger[:,3],np.minimum.accumulate(ledger[:,2]))
            assert np.allclose(r['gains'],b.decode(ledger[np.argmin(ledger[:,2]),4:],b.original.config()))
            base=json.loads((ex.STUDY/'drones'/name/'runs'/f'{seed}.json').read_text()); bm=b.metrics(plants[name],base['gains'],b.original.config())
            check=b.metrics(plants[name],r['gains'],b.original.config()); assert all(np.isclose(check[k],r[k]) for k in check)
            ok=r['training_feasible'] and bm['training_feasible'] and r['mean_settling_s']<=1.05*bm['mean_settling_s'] and r['worst_settling_s']<=1.05*bm['worst_settling_s'] and r['local_passes']>=bm['local_passes'] and r['combined_passes']>=bm['combined_passes']
            rows.append(dict(drone=name,seed=seed,evaluations=900,**check,settling_ratio_to_reference=r['mean_settling_s']/bm['mean_settling_s'],meets_target=ok))
            gains.append(dict(drone=name,seed=seed,**dict(zip([p['name'] for p in b.original.config()['parameters']],r['gains'])),meets_target=ok))
    b.write_csv(ROOT/'comparison.csv',rows); b.write_csv(ROOT/'final_gains.csv',gains)
    summary={'status':'COMPLETE','runs':30,'passed':sum(r['meets_target'] for r in rows),'feasible':sum(r['training_feasible'] for r in rows),'median_settling_ratio':float(np.median([r['settling_ratio_to_reference'] for r in rows])),'audit':'PASS','method':'Neural + GP predictions + training-controller library; not neural-only'}
    save('STATUS.json',summary); print(json.dumps(summary,indent=2),flush=True)
if __name__=='__main__': main()
