"""Audit the completed frozen test and publish descriptive paired results."""
import html
import json
from pathlib import Path
from statistics import median

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import run

root=run.OUT
names={'ordinary':'Ordinary PSO','predictions':'NN + GP predictions','library':'Controller library','hybrid':'Full hybrid','reference':'Full PSO reference'}

def table(headers, rows):
    cell=lambda v:html.escape(str(v))
    return '<table><tr>'+''.join('<th>'+cell(h)+'</th>' for h in headers)+'</tr>'+''.join('<tr>'+''.join('<td>'+cell(x)+'</td>' for x in r)+'</tr>' for r in rows)+'</table>'

def median_field(rows,field):
    return float(median(r[field] for r in rows))

def main():
    assert run.read(root/'status.json')['completed']==150
    protocol=run.read(root/'protocol.json')
    assert all(run.sha(Path(p))==h for p,h in protocol['contract']['hashes'].items())
    plants=run.read(root/'plants.json'); cfg=run.b.original.config()
    rows=[]; gains=[]; by_drone=[]; audit=[]; all_seeds=run.SEEDS
    for d in plants:
        directory=root/d['id']; run.save(directory/'specification.json',d)
        for seed in all_seeds:
            ref=run.read(directory/f'reference_{seed}.json')
            with np.load(directory/f'ordinary_{seed}.npz') as pair:
                velocities=pair['velocity']; initial=pair['initial']
            for m in run.METHODS:
                stem=directory/f'{m}_{seed}'; r=run.read(stem.with_suffix('.json'))
                assert (r['method'],r['seed'],r['drone'])==(m,seed,d['id'])
                with np.load(stem.with_suffix('.npz')) as archive:
                    z=archive['ledger']; x=archive['initial']; v=archive['velocity']
                n=3264 if m=='reference' else 1800
                assert r['evaluations']==n and z.shape==(n,12) and np.isfinite(z).all()
                assert np.array_equal(z[:,0],np.arange(1,n+1)) and len(np.unique(z[:,4:].round(13),axis=0))==n
                assert np.array_equal(z[:,3],np.minimum.accumulate(z[:,2]))
                assert np.array_equal(v,velocities) and np.array_equal(initial[33:],x[33:]) and np.array_equal(initial[0],x[0])
                if m=='reference': assert np.array_equal(initial,x)
                assert np.allclose(run.b.decode(z[z[:,2].argmin(),4:],cfg),r['gains'])
                checked=run.b.metrics(d,r['gains'],cfg)
                assert all(np.isclose(checked[k],r[k],atol=1e-10,rtol=1e-10) for k in checked)
                a=r['mean_settling_s']/ref['mean_settling_s']; w=r['worst_settling_s']/ref['worst_settling_s']
                failures=[key for key,ok in [('training feasibility',r['training_feasible']),('reference feasibility',ref['training_feasible']),
                    ('mean settling',r['mean_settling_s']<=1.05*ref['mean_settling_s']),('worst settling',r['worst_settling_s']<=1.05*ref['worst_settling_s']),
                    ('local robustness',r['local_passes']>=ref['local_passes']),('combined robustness',r['combined_passes']>=ref['combined_passes'])] if not ok]
                g=r.pop('gains')
                rows.append(dict(**r,mean_ratio=a,worst_ratio=w,passed=not failures,failed_criteria=', '.join(failures)))
                gains.append(dict(drone=d['id'],seed=seed,method=m,**dict(zip([p['name'] for p in cfg['parameters']],g))))
                audit.append(dict(drone=d['id'],seed=seed,method=m,evaluations=n,verified=True))
        subset=[r for r in rows if r['drone']==d['id']]
        run.b.write_csv(directory/'comparison.csv',subset)
        run.b.write_csv(directory/'gains.csv',[r for r in gains if r['drone']==d['id']])
        for m in run.METHODS:
            rr=[r for r in subset if r['method']==m]
            by_drone.append(dict(drone=d['id'],method=m,passes=sum(r['passed'] for r in rr),runs=3,
                median_mean_settling_s=median_field(rr,'mean_settling_s'),median_worst_settling_s=median_field(rr,'worst_settling_s'),
                local_passes=sum(r['local_passes'] for r in rr),local_total=180,combined_passes=sum(r['combined_passes'] for r in rr),combined_total=36,
                median_tuning_s=median_field(rr,'tuning_seconds'),failures=' | '.join(f"{r['seed']}: {r['failed_criteria']}" for r in rr if not r['passed'])))
    assert len(rows)==150
    summaries=[]
    for m in run.METHODS:
        rr=[r for r in rows if r['method']==m]
        summaries.append(dict(method=m,evaluations=rr[0]['evaluations'],passes=sum(r['passed'] for r in rr),runs=len(rr),
            training_feasible=sum(r['training_feasible'] for r in rr),median_mean_settling_s=median_field(rr,'mean_settling_s'),
            median_worst_settling_s=median_field(rr,'worst_settling_s'),median_mean_ratio=median_field(rr,'mean_ratio'),
            local_passes=sum(r['local_passes'] for r in rr),combined_passes=sum(r['combined_passes'] for r in rr),
            median_optimizer_s=median_field(rr,'optimizer_seconds'),median_lookup_s=median_field(rr,'initializer_lookup_seconds'),median_tuning_s=median_field(rr,'tuning_seconds')))
    for file,data in [('per_run.csv',rows),('final_gains.csv',gains),('per_drone.csv',by_drone),('summary.csv',summaries),('audit.csv',audit)]:
        run.b.write_csv(root/file,data)
    paired={(r['drone'],r['seed'],r['method']):r for r in rows}
    comparisons=[]
    for m in ['ordinary','predictions','library','reference']:
        paired_diff=[]; won=lost=0; time_ratios=[]
        for d in plants:
            differences=[]
            for s in all_seeds:
                h=paired[d['id'],s,'hybrid']; other=paired[d['id'],s,m]
                diff=int(h['passed'])-int(other['passed']); differences.append(diff)
                won+=diff==1; lost+=diff==-1; time_ratios.append(h['tuning_seconds']/other['tuning_seconds'])
            paired_diff.append(np.mean(differences))
        boot=np.random.default_rng(6801).choice(paired_diff,(20000,10),replace=True).mean(axis=1)
        comparisons.append(dict(comparator=m,hybrid_only_passes=won,comparator_only_passes=lost,
            paired_pass_difference_pp=100*float(np.mean(paired_diff)),cluster_bootstrap_low_pp=100*float(np.quantile(boot,.025)),
            cluster_bootstrap_high_pp=100*float(np.quantile(boot,.975)),median_paired_time_saving_pct=100*(1-float(np.median(time_ratios)))))
    run.b.write_csv(root/'paired_comparisons.csv',comparisons)
    bundle=run.read(run.PROJECT/'candidate_predictions.json')
    stored=[run.read(p) for name in bundle['training_ids'] for p in (run.STUDY/'drones'/name/'runs').glob('*.json')]
    screen=[run.read(p) for p in (run.PROJECT/'portfolio/training_cv').glob('*/*.json')]
    assert len(stored)==600 and len(screen)==40
    offline=dict(label_generation_runs=len(stored),label_generation_evals=sum(r['unique_evaluations'] for r in stored),
        label_optimizer_sum_seconds=sum(r['seconds'] for r in stored),candidate_training_recorded_wall_seconds=bundle['seconds'],
        candidate_cross_validation_controller_scores=len(bundle['candidates'])*len(bundle['training_ids']),
        portfolio_screen_runs=len(screen),portfolio_screen_evals=sum(r['unique_evaluations'] for r in screen),
        portfolio_screen_optimizer_sum_seconds=sum(r['seconds'] for r in screen),
        model_load_seconds=run.read(root/'predictions.json')['load_seconds'],library_build_seconds=run.read(root/'inputs.json')['library_load_seconds'],
        primary_test_evaluations=sum(r['evaluations'] for r in rows),
        cost_scope='Label generation and screening times sum run durations across workers. Training time is elapsed. They are not additive wall time. Prior development budget sweeps, validation simulations, compilation and audits are outside online evaluation counts. No complete historical project wall time was recorded.')
    development=[]
    for directory,pattern in [(run.STUDY/'Orange_900_Pilot'/'results','*/*.json'),(run.PROJECT/'results','*/*.json'),(run.PROJECT/'portfolio'/'validation','*/*.json')]+[(run.PROJECT/f'hybrid_{n}','Drone_*/*.json') for n in (1200,1500,1700,1800,1900)]:
        runs=[run.read(f) for f in directory.glob(pattern)]
        development.append(dict(stage=str(directory.relative_to(run.STUDY)),runs=len(runs),evaluations=sum(r.get('unique_evaluations',r.get('evaluations',0)) for r in runs),optimizer_sum_seconds=sum(r['seconds'] for r in runs)))
    offline['previous_development_comparisons']=development
    run.save(root/'offline_costs.json',offline)
    fig,axs=plt.subplots(1,2,figsize=(13,5),layout='constrained')
    axs[0].barh([names[r['method']] for r in summaries[:-1]],[r['passes'] for r in summaries[:-1]],color=['#8392a5','#5089cc','#429d8b','#6e52a3'])
    axs[0].set(xlim=(0,31),xlabel='Paired runs meeting every criterion (out of 30)')
    for i,r in enumerate(summaries[:-1]): axs[0].text(r['passes']+.15,i,str(r['passes']),va='center')
    matrix=np.array([[next(r['passes'] for r in by_drone if r['drone']==d['id'] and r['method']==m) for m in run.METHODS[:4]] for d in plants])
    axs[1].imshow(matrix,vmin=0,vmax=3,cmap='Blues',aspect='auto')
    axs[1].set(yticks=range(10),yticklabels=[d['id'] for d in plants],xticks=range(4),xticklabels=['Ordinary','Predictions','Library','Hybrid'],title='Passing seeds per drone (out of 3)')
    for i,j in np.ndindex(matrix.shape): axs[1].text(j,i,str(matrix[i,j]),ha='center',va='center',color='white' if matrix[i,j]>=2 else 'black')
    fig.savefig(root/'outcomes.png',dpi=160); plt.close(fig)
    content=['<!doctype html><meta charset=utf-8><title>Independent 1,800-evaluation comparison</title><style>body{font:16px system-ui;max-width:1160px;margin:36px auto;padding:0 20px;color:#182637}table{border-collapse:collapse;margin:16px 0}td,th{padding:7px;border:1px solid #cbd5e1}th{background:#edf4f9}img{max-width:100%}a{color:#24558c}</style>',
        '<h1>Independent test of quadrotor controller tuning</h1>',
        f"<p>Protocol frozen at {protocol['frozen_utc']}. Ten fresh simulated healthy configurations and three paired random seeds per configuration. Selection, gain bounds, optimizer schedule and budget were fixed before generating plants. Each run used six training commands and was scored against the full-budget ordinary PSO reference for its own drone and seed.</p>",
        '<p>Pass requires feasible training responses in both controllers, mean and worst settling times within 5% above reference, and at least as many passing local and combined cases. Local counts are out of 60 per run and combined counts out of 12. Matching a zero reference count can satisfy the relative combined criterion.</p>',
        table(['Method','Evaluations','Quality passes /30','Feasible /30','Median mean settling (s)','Median worst settling (s)','Local passes /1800','Combined passes /360','Median tuning (s)'],[[names[r['method']],r['evaluations'],r['passes'] if r['method']!='reference' else 'Reference',r['training_feasible'],f"{r['median_mean_settling_s']:.4f}",f"{r['median_worst_settling_s']:.4f}",r['local_passes'],r['combined_passes'],f"{r['median_tuning_s']:.2f}"] for r in summaries]),
        '<img src="outcomes.png"><h2>Paired comparisons</h2><p>Intervals resample whole drones with all three seeds together. Ten configurations limit precision. Predictions use the frozen neural ensemble and Gaussian process as a group. The library retrieves 20 complete controllers from the 20 training drones. Component comparisons measure the benefit of each group.</p>',
        table(['Hybrid compared with','Hybrid alone passed','Comparator alone passed','Pass difference (percentage points)','Descriptive 95% drone-bootstrap interval','Median paired tuning-time saving'],[[names[r['comparator']],r['hybrid_only_passes'],r['comparator_only_passes'],f"{r['paired_pass_difference_pp']:+.1f}",f"{r['cluster_bootstrap_low_pp']:+.1f} to {r['cluster_bootstrap_high_pp']:+.1f}",f"{r['median_paired_time_saving_pct']:+.1f}%"] for r in comparisons if r['comparator']!='reference']),
        '<h2>Results by drone</h2>',
        table(['Drone','Method','Passes /3','Median mean / worst settling (s)','Local /180','Combined /36','Median tuning (s)','Failed seed and criteria'],[[r['drone'],names[r['method']],r['passes'] if r['method']!='reference' else 'Reference',f"{r['median_mean_settling_s']:.4f} / {r['median_worst_settling_s']:.4f}",r['local_passes'],r['combined_passes'],f"{r['median_tuning_s']:.2f}",r['failures']] for r in by_drone]),
        '<h2>Cost and scope</h2><p>Online tuning time combines measured elapsed PSO optimization with median warm prediction and retrieval time per query. Four concurrent workers were used, with a shuffled method order and simulator warm-up. Startup, disk model loading, library construction, post-run robustness tests and auditing are excluded. Timings describe this computer under this workload.</p>',
        table(['Offline activity','Recorded cost'],[['600 archived training searches',f"{offline['label_generation_evals']:,} evaluations; {offline['label_optimizer_sum_seconds']/3600:.2f} summed optimizer hours"],['Candidate model training',f"{bundle['seconds']:.1f} elapsed seconds"],['Training-only controller scoring',f"{offline['candidate_cross_validation_controller_scores']} additional controller scores; separate time unavailable"],['Library-method screen',f"{offline['portfolio_screen_evals']:,} evaluations; {offline['portfolio_screen_optimizer_sum_seconds']/3600:.2f} summed optimizer hours"],['Warm-start setup',f"model load {offline['model_load_seconds']:.3f} s; library build {offline['library_build_seconds']:.3f} s"]]),
        '<h3>Additional historical development runs</h3>'+table(['Development experiment','Searches','Evaluations','Summed optimizer hours'],[[r['stage'],r['runs'],f"{r['evaluations']:,}",f"{r['optimizer_sum_seconds']/3600:.2f}"] for r in development]),
        '<p>The 1,800 budget saves 44.9% of objective evaluations per tuning run against 3,264. Offline development costs and summed worker durations are separate. These results cover the simulated design ranges and controller only. The study has ten independent plants. The three runs per plant repeat the search on that same plant.</p>',
        '<p><a href="protocol.json">Frozen protocol and hashes</a> · <a href="plants.json">Drone specifications</a> · <a href="per_run.csv">Every run, timings and failed criteria</a> · <a href="per_drone.csv">Per-drone summaries</a> · <a href="final_gains.csv">Final gains</a> · <a href="offline_costs.json">Offline costs</a> · <a href="audit.csv">Audit</a></p>']
    (root/'REPORT.html').write_text(''.join(content),encoding='utf-8')
    run.save(root/'status.json',dict(status='COMPLETE',completed=150,total=150,audit='PASS',summary=summaries,comparisons=comparisons))
    print(json.dumps(summaries,indent=2))
if __name__=='__main__':
    main()
